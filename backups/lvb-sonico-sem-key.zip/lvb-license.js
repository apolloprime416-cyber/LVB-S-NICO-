// LVB Sônico — versão livre (cópia sem validação de key)
// Esta cópia NÃO exige licença: tudo é liberado automaticamente.
(function () {
  const API_BASE = "https://lvbsonic.replit.app";
  const RESET_PAGE = API_BASE + "/resetar-key";

  const FREE_KEY = "LVB-FREE-0000-0000";

  function freeResult(key) {
    return {
      valid: true,
      reason: null,
      message: "Bem-vindo ao LVB Sônico.",
      expires_at: null,
      activated_at: null,
      status: "active",
      license_type: "paid",
      lifetime: true,
      session_id: key || FREE_KEY,
      user_name: null,
      online_count: 0,
      plan: "lifetime",
    };
  }

  // Sempre válido, sem consultar servidor.
  async function lvbValidate(_fetcher, key, _deviceId) {
    return freeResult(key);
  }

  // Marca a licença como válida no armazenamento assim que carrega,
  // para pular a tela de inserir key.
  try {
    if (typeof chrome !== "undefined" && chrome.storage && chrome.storage.local) {
      chrome.storage.local.set({
        ql_license_valid: true,
        ql_license_key: FREE_KEY,
        ql_session_id: FREE_KEY,
        ql_user_name: null,
        ql_expires_at: null,
        ql_activated_at: null,
        ql_license_status: "active",
        ql_license_type: "paid",
        ql_license_lifetime: true,
      });
    }
  } catch (_) {}

  const root = typeof window !== "undefined" ? window : self;
  root.LVB_API_BASE = API_BASE;
  root.LVB_API_BASES = [API_BASE];
  root.LVB_VALIDATE_URL = API_BASE + "/api/public/validate";
  root.LVB_RESET_PAGE = RESET_PAGE;
  root.lvbValidate = lvbValidate;
})();
